"""CSC111 Final Project: Checkers & Decision Trees

Module Description
==================
This module contains all constants and functions required for showing the game and all the visual representations
regarding progression of a game. The game is our main visualization and shows how well the AI perform against a
Random player.

Copyright and Usage Information
===============================
This file is Copyright (c) 2023 Samarth Sharma, Lakshman Nair, Peter James, and Mimis Chlympatsos.
"""

import asyncio
import pygame
from structures import CheckersGame, Move
from simulation import run_game
from players import PrunelessMinimaxer, Randomizer, PrunefulMinimaxer, AdvancedAggressor

# Constants
BLACK = (0, 0, 0)
RED = (225, 0, 0)
WHITE = (255, 255, 255)
LIGHT_GREY = (150, 150, 150)
GREEN = (25, 225, 0)
YELLOW = (225, 255, 0)
BLUE = (0, 100, 225)
GREY = (75, 75, 75)
ORANGE = (255, 165, 0)
LIGHT_RED = (229, 48, 36)
TEAL = (0, 255, 255)

SQUARE_SIZE = 100
ROWS, COLS = 8, 8

# AI search depth kept at 2 for browser responsiveness (Wasm is ~3-5x slower).
AI_DEPTH = 2

width = 800
height = 800
SIZE = (width, height)

# Display / fonts are created lazily so pygbag can finish loading pygame-ce
# before we touch the display surface (module-level init breaks on Wasm).
screen = None
font = font_two = font_three = font_four = font_five = font_six = None


def init_display() -> None:
    """Create the window and load fonts. Safe to call more than once."""
    global screen, font, font_two, font_three, font_four, font_five, font_six
    if screen is not None:
        return
    if not pygame.get_init():
        pygame.init()
    screen = pygame.display.set_mode(SIZE)
    pygame.display.set_caption("Checkers & Decision Trees")
    font = pygame.font.Font('font_files/Plexiglass.ttf', 125)
    font_two = pygame.font.Font('font_files/Plexiglass.ttf', 30)
    font_three = pygame.font.Font('font_files/Plexiglass.ttf', 75)
    font_four = pygame.font.Font('font_files/Plexiglass.ttf', 50)
    font_five = pygame.font.Font('font_files/Roboto-Medium.ttf', 30)
    font_six = pygame.font.Font('font_files/Star Trek_future.ttf', 45)


class Piece:
    """Class for drawing each individual stone. This class has been separated to divide the backend from the front end;
    stone is a class used for the algorithms that generate a gameboard, however Piece is used to transfer the stone
    data to the front end so that it can be drawn. It takes in the row, column and colour of the stone it retrieves
    by accessing the CheckersGame.stones dictionary with the id from the CheckersGame.board. It uses this data to
    calculate where the piece should be drawn on the screen, using the calculate_position method, and the colour it
    should be, which is done in the drawPiece function. This class and its methods are integral to drawing each
    board."""

    def __init__(self, row, column, colour):
        self.row = row
        self.column = column
        self.colour = colour
        self.xco = 0
        self.yco = 0
        self.calculate_position()

    def calculate_position(self):
        """Calculate the x and y coordinates of a piece given its stone position."""
        self.xco = SQUARE_SIZE * self.column + SQUARE_SIZE // 2
        self.yco = SQUARE_SIZE * self.row + SQUARE_SIZE // 2

    def drawPiece(self, screen: pygame.Surface) -> None:
        """Draw the piece based on the stone data and its calculated position. Use a small grey outline to make the
        pieces look smoother."""
        radius = SQUARE_SIZE // 2 - 15
        pygame.draw.circle(screen, GREY, (self.xco, self.yco), radius + 2)
        pygame.draw.circle(screen, self.colour, (self.xco, self.yco), radius)


# Draw functions - for the menu, how to play screen and end screen

def draw_menu() -> None:
    """A function that draws the menu/user interface."""
    pygame.draw.rect(screen, BLACK, (0, 0, width, height))

    title = font.render('Checkers', True, LIGHT_RED)
    screen.blit(title, pygame.Rect(80, 100, 50, 100))
    subheading = font_two.render('     WATCH', True, YELLOW)
    screen.blit(subheading, pygame.Rect(100, 200, 50, 20))
    subheading2 = font_two.render('              OUR', True, YELLOW)
    screen.blit(subheading2, pygame.Rect(200, 200, 50, 20))
    subheading3 = font_two.render('        NEW', True, YELLOW)
    screen.blit(subheading3, pygame.Rect(383, 200, 50, 20))
    subheading4 = font_two.render('       AI', True, YELLOW)
    screen.blit(subheading4, pygame.Rect(538, 200, 50, 20))

    # Drawing the rectangles for buttons in the menu
    pygame.draw.rect(screen, WHITE, (185, 300, 400, 100))
    pygame.draw.rect(screen, BLACK, (190, 305, 390, 90))
    play = font_three.render('PLAY', True, GREEN)
    screen.blit(play, pygame.Rect(298, 320, 50, 20))

    pygame.draw.rect(screen, WHITE, (185, 425, 400, 100))
    pygame.draw.rect(screen, BLACK, (190, 430, 390, 90))
    guide = font_three.render('GUIDE', True, WHITE)
    screen.blit(guide, pygame.Rect(280, 445, 50, 20))

    pygame.draw.rect(screen, WHITE, (185, 550, 400, 100))
    pygame.draw.rect(screen, BLACK, (190, 555, 390, 90))
    exit_button = font_three.render('EXIT', True, RED)
    screen.blit(exit_button, pygame.Rect(310, 570, 50, 20))

    pygame.display.flip()


def draw_choose_AI() -> None:
    """A function that draws the screen after someone presses play. It includes buttons for each AI combination"""
    pygame.draw.rect(screen, BLACK, (0, 0, width, height))

    title = font.render('Choose AI', True, GREEN)
    screen.blit(title, pygame.Rect(80, 100, 50, 100))

    # Drawing the rectangles for buttons in the menu
    button_width = 350
    button_height = 100
    spacing = 30

    x_start = 45
    y_start = 250

    for i in range(4):
        y = y_start + (button_height + spacing) * i
        pygame.draw.rect(screen, WHITE, (x_start, y, button_width, button_height))
        pygame.draw.rect(screen, BLACK, (x_start + 5, y + 5, button_width - 10, button_height - 10))

    ai_1 = font_six.render('Pruneless V Random', True, ORANGE)
    screen.blit(ai_1, pygame.Rect(x_start + 45, y_start + 20, 50, 20))

    ai_2 = font_six.render('Pruneful V Random', True, ORANGE)
    screen.blit(ai_2, pygame.Rect(x_start + 46, y_start + 150, 50, 20))

    ai_3 = font_six.render('Pruneful V Pruneless', True, ORANGE)
    screen.blit(ai_3, pygame.Rect(x_start + 32, y_start + 280, 50, 20))

    ai_4 = font_six.render('Pruneful V Aggressor', True, ORANGE)
    screen.blit(ai_4, pygame.Rect(x_start + 30, y_start + 410, 50, 20))

    x_start = 400

    for i in range(4):
        y = y_start + (button_height + spacing) * i
        pygame.draw.rect(screen, WHITE, (x_start, y, button_width, button_height))
        pygame.draw.rect(screen, BLACK, (x_start + 5, y + 5, button_width - 10, button_height - 10))

    ai_5 = font_six.render('Random V Pruneless', True, ORANGE)
    screen.blit(ai_5, pygame.Rect(x_start + 45, y_start + 20, 50, 20))

    ai_6 = font_six.render('Random V Pruneful', True, ORANGE)
    screen.blit(ai_6, pygame.Rect(x_start + 46, y_start + 150, 50, 20))

    ai_7 = font_six.render('Pruneless V Pruneful', True, ORANGE)
    screen.blit(ai_7, pygame.Rect(x_start + 32, y_start + 280, 50, 20))

    ai_8 = font_six.render('Aggressor V Pruneful', True, ORANGE)
    screen.blit(ai_8, pygame.Rect(x_start + 30, y_start + 410, 50, 20))

    pygame.display.flip()


def draw_squares(screen: pygame.Surface) -> None:
    """A function that draws the gameboard by filling the screen with red and drawing black squares in every other
    position in each row and column."""
    screen.fill(RED)
    for row in range(ROWS):
        for col in range(row % 2, COLS, 2):
            pygame.draw.rect(screen, BLACK, (row * SQUARE_SIZE, col * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))


# changed input to list from game.board
def draw(game: CheckersGame, screen: pygame.Surface) -> None:
    """Given a game_state, using the board attribute of that game_state, draw the state of the checkers board.
    draw_sqaures draws the red and black squares and drawPiece draws the pieces on the correct squares."""
    draw_squares(screen)
    for row in game.board:
        for id in row:
            if id != -1:
                stone = game.stones[id]
                if stone.color == 'R':
                    colour = (255, 0, 0)
                else:
                    colour = (128, 128, 128)
                newpiece = Piece(stone.position[0], stone.position[1], colour)
                newpiece.drawPiece(screen)


async def yield_frames(frames: int) -> bool:
    """Yield control for approximately `frames` frames. Returns False if the user quit."""
    for _ in range(frames):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
        await asyncio.sleep(0)
    return True


async def draw_boards(game_states: list[CheckersGame]) -> bool:
    """Animate a sequence of board states. Returns False if the user quit mid-animation."""
    for game_state in game_states:
        draw_squares(screen)
        draw(game_state, screen)
        screen.blit(pygame.transform.rotate(screen, 90), (0, 0))
        pygame.display.flip()
        # Non-blocking ~500ms delay (~30 frames), yielding to the browser each frame
        if not await yield_frames(30):
            return False
    return True


def draw_guide() -> None:
    """Draw the screen the pops up after guide is selected."""
    screen.fill(BLACK)
    lines = [
        ('Welcome to our final project for CSC111!!', LIGHT_RED, 50),
        ('This screen explains the rules and assumptions made', LIGHT_RED, 90),
        ('in this simulation of a checkers game. The game of', LIGHT_RED, 130),
        ('checkers is played with 12 red and 12 black pieces.', LIGHT_RED, 170),
        ('These pieces begin, and can only move between black', LIGHT_RED, 210),
        ('squares. As a simplifying assumption stones cannot', LIGHT_RED, 250),
        ('become kings and are useless once they reach their', LIGHT_RED, 290),
        ('respective furthest row. Additionally, pieces', LIGHT_RED, 330),
        ('cannot change direction in the case of capturing', LIGHT_RED, 370),
        ('more than one stone at once. We have eight', LIGHT_RED, 410),
        ('total options on different AI combinations you can', LIGHT_RED, 450),
        ('run. The option on the left side of the button is', LIGHT_RED, 490),
        ('the black side for that simulation. Pick a matchup', LIGHT_RED, 530),
        ('and watch the animated replay. Enjoy the AIs!', LIGHT_RED, 570),
        ('Click or press Enter to return to the menu.', WHITE, 650),
    ]
    for text, colour, y in lines:
        rendered = font_six.render(text, True, colour)
        x = 150 if colour == WHITE else (75 if y == 50 else 30)
        screen.blit(rendered, pygame.Rect(x, y, 50, 20))
    pygame.display.flip()


def draw_win(game: CheckersGame) -> None:
    """Draw the screen the pops up when the game ends. It will slightly differ based on who wins."""
    screen.fill(BLACK)
    winText = font.render('GAME OVER', True, YELLOW)
    screen.blit(winText, pygame.Rect(50, 100, 50, 20))
    if game.get_winner() == 'R':
        text = font_three.render('RED WINS!', True, RED)
        screen.blit(text, pygame.Rect(199, 250, 50, 20))
    else:
        text = font_three.render('BLACK WINS!', True, WHITE)
        screen.blit(text, pygame.Rect(175, 250, 50, 20))

    win_caption = font_two.render('Hope you found this simulation '
                                  'interesting!', True, YELLOW)
    screen.blit(win_caption, pygame.Rect(55, 350, 50, 20))
    win_caption_2 = font_two.render('We encourage you to run through each AI!', True, YELLOW)
    screen.blit(win_caption_2, pygame.Rect(50, 450, 50, 20))
    win_caption3 = font_two.render('Click or press a key to return.', True, YELLOW)
    screen.blit(win_caption3, pygame.Rect(120, 550, 50, 20))
    pygame.display.flip()


def draw_computing() -> None:
    """Show a Computing... indicator while the AI search runs."""
    screen.fill(BLACK)
    computing_text = font_three.render('Computing...', True, YELLOW)
    screen.blit(computing_text, pygame.Rect(200, 350, 50, 20))
    hint = font_two.render('AI is searching (depth 2) — usually under a second', True, WHITE)
    screen.blit(hint, pygame.Rect(70, 450, 50, 20))
    pygame.display.flip()


def hit_menu_button(mx: int, my: int) -> str | None:
    """Return which menu button was clicked, if any."""
    if 185 < mx < 585 and 305 < my < 395:
        return 'play'
    if 185 < mx < 585 and 430 < my < 520:
        return 'guide'
    if 185 < mx < 585 and 555 < my < 645:
        return 'exit'
    return None


def hit_ai_button(mx: int, my: int) -> int | None:
    """Return AI matchup index 1-8 if a button was clicked, else None."""
    rows = [(250, 350), (380, 480), (510, 610), (640, 740)]
    if 45 < mx < 395:
        for i, (y0, y1) in enumerate(rows):
            if y0 < my < y1:
                return i + 1
    if 400 < mx < 750:
        for i, (y0, y1) in enumerate(rows):
            if y0 < my < y1:
                return i + 5
    return None


def make_players(choice: int):
    """Return (black_player, red_player) for the selected matchup."""
    if choice == 1:
        return PrunelessMinimaxer(AI_DEPTH), Randomizer()
    if choice == 2:
        return PrunefulMinimaxer(AI_DEPTH), Randomizer()
    if choice == 3:
        return PrunefulMinimaxer(AI_DEPTH), PrunelessMinimaxer(AI_DEPTH)
    if choice == 4:
        return PrunefulMinimaxer(AI_DEPTH), AdvancedAggressor('R', AI_DEPTH)
    if choice == 5:
        return Randomizer(), PrunelessMinimaxer(AI_DEPTH)
    if choice == 6:
        return Randomizer(), PrunefulMinimaxer(AI_DEPTH)
    if choice == 7:
        return PrunelessMinimaxer(AI_DEPTH), PrunefulMinimaxer(AI_DEPTH)
    if choice == 8:
        return AdvancedAggressor('B', AI_DEPTH), PrunefulMinimaxer(AI_DEPTH)
    raise ValueError(f'Unknown AI choice: {choice}')


async def play_matchup(choice: int) -> CheckersGame | None:
    """Run one AI matchup: compute, animate, pause, then show the winner screen."""
    black, red = make_players(choice)
    draw_computing()
    await asyncio.sleep(0)

    existing_game, _winner = run_game(black, red)
    create_game = CheckersGame()
    moves = existing_game.get_moves()
    game_states = game_state_generator(moves, create_game)

    if not await draw_boards(game_states):
        return None

    # Brief pause on the final board before the winner screen (~1s)
    if not await yield_frames(60):
        return None

    draw_win(existing_game)
    return existing_game


async def wait_for_click() -> bool:
    """Wait until the user clicks/presses a key, or quits. Returns False on quit."""
    # Drain any click that opened this screen
    was_pressed = True
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                return True
            if event.type == pygame.KEYDOWN:
                return True
        pressed = pygame.mouse.get_pressed()[0]
        if pressed and not was_pressed:
            return True
        was_pressed = pressed
        await asyncio.sleep(0)


# Main game loop function
async def games() -> None:
    init_display()
    myClock = pygame.time.Clock()

    # screen: 'menu' | 'choose' | 'guide'
    screen_state = 'menu'
    running = True
    # Edge-detect mouse presses so Wasm/CSS scaling quirks still feel responsive
    was_pressed = False

    while running:
        myClock.tick(60)

        if screen_state == 'menu':
            draw_menu()
        elif screen_state == 'choose':
            draw_choose_AI()
        elif screen_state == 'guide':
            draw_guide()

        clicked = False
        click_pos = (0, 0)
        key_action = None  # ('menu', 'play'|'guide'|'exit') | ('choose', 1-8) | ('guide', 'back')

        for evnt in pygame.event.get():
            if evnt.type == pygame.QUIT:
                running = False
                break
            # Prefer button-up events; also accept button-down for Wasm browsers
            if evnt.type in (pygame.MOUSEBUTTONUP, pygame.MOUSEBUTTONDOWN) and evnt.button == 1:
                clicked = True
                click_pos = evnt.pos
            if evnt.type == pygame.KEYDOWN:
                if screen_state == 'menu':
                    if evnt.key in (pygame.K_p, pygame.K_RETURN, pygame.K_SPACE):
                        key_action = ('menu', 'play')
                    elif evnt.key == pygame.K_g:
                        key_action = ('menu', 'guide')
                    elif evnt.key == pygame.K_ESCAPE:
                        key_action = ('menu', 'exit')
                elif screen_state == 'guide':
                    if evnt.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_SPACE, pygame.K_BACKSPACE):
                        key_action = ('guide', 'back')
                elif screen_state == 'choose':
                    if pygame.K_1 <= evnt.key <= pygame.K_8:
                        key_action = ('choose', evnt.key - pygame.K_0)
                    elif evnt.key == pygame.K_ESCAPE:
                        key_action = ('choose', 'back')

        # Fallback: poll pressed state (helps when synthetic/OS events are flaky)
        pressed = pygame.mouse.get_pressed()[0]
        if pressed and not was_pressed:
            clicked = True
            click_pos = pygame.mouse.get_pos()
        was_pressed = pressed

        if running and key_action is not None:
            kind, value = key_action
            if kind == 'menu':
                if value == 'play':
                    screen_state = 'choose'
                elif value == 'guide':
                    screen_state = 'guide'
                elif value == 'exit':
                    running = False
            elif kind == 'guide':
                screen_state = 'menu'
            elif kind == 'choose':
                if value == 'back':
                    screen_state = 'menu'
                else:
                    result = await play_matchup(value)
                    if result is None:
                        running = False
                    elif not await wait_for_click():
                        running = False
                    else:
                        screen_state = 'menu'
            was_pressed = True

        elif running and clicked:
            mx, my = click_pos
            # Capture state before handling so DOWN+UP in one frame can't chain screens
            state = screen_state

            if state == 'menu':
                button = hit_menu_button(mx, my)
                if button == 'play':
                    screen_state = 'choose'
                elif button == 'guide':
                    screen_state = 'guide'
                elif button == 'exit':
                    # End the loop cleanly (no sys.exit / quit — those crash Wasm tabs)
                    running = False

            elif state == 'guide':
                screen_state = 'menu'

            elif state == 'choose':
                choice = hit_ai_button(mx, my)
                if choice is not None:
                    result = await play_matchup(choice)
                    if result is None:
                        running = False
                    else:
                        # Stay on winner screen until click, then return to menu
                        if not await wait_for_click():
                            running = False
                        else:
                            screen_state = 'menu'

            was_pressed = True

        await asyncio.sleep(0)


# Helper: We need this function to get a list of gamestates based on which visual of the game works, by calling
# the draw_boards function.
def game_state_generator(lst_moves: list[Move], game: CheckersGame) -> list[CheckersGame]:
    """
    Given a list of moves, this function returns a list of sequentially updated game state (i.e. CheckersGame objects)
    by utilizing the CheckersGame.copy_and_record method.
    """
    lst = [game]
    for move in lst_moves:
        new_game = game.copy_and_record_move(move)
        lst.append(new_game)
        game = new_game

    return lst


# If you run this main file, the game runs.
if __name__ == '__main__':
    asyncio.run(games())
