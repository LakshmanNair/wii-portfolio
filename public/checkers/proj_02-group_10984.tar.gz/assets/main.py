# /// script
# dependencies = [
#   "pygame.base",
# ]
# ///
"""CSC111 Final Project: Checkers & Decision Trees

Module Description
==================
This is the main module of the project. Pygbag requires the entrypoint to be
named main.py with an async game loop that yields via await asyncio.sleep(0).

Copyright and Usage Information
===============================
This file is Copyright (c) 2023 Samarth Sharma, Lakshman Nair, Peter James, and Mimis Chlympatsos.
"""
import asyncio


async def main():
    # Yield so pygbag can finish installing the pygame-ce Wasm wheel
    # (dependency "pygame.base" above) before we touch the display.
    await asyncio.sleep(0)

    import pygame
    pygame.init()

    from visual import games
    await games()


asyncio.run(main())
